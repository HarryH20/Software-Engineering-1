package edu.baylor.ecs.si.Module3;

public class RoadBikeHolder extends BicycleHolder {
    public RoadBikeHolder(RoadBike bicycle){
        super(bicycle);
    }

}
