package edu.baylor.ecs.si.Module3;

public class MountainBikeHolder extends BicycleHolder{
    public MountainBikeHolder(MountainBike bicycle) {
        super(bicycle);
    }

}
