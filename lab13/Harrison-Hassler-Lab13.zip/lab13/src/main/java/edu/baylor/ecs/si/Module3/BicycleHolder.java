package edu.baylor.ecs.si.Module3;

public class BicycleHolder {
    protected Bicycle bicycle;
    public BicycleHolder(Bicycle bicycle){
        this.bicycle = bicycle;


    }
}
